package com.bdx.rainbow.mapp.model.rsp;

import com.bdx.rainbow.mapp.model.BDXBody;

import java.io.Serializable;

public class YZ0001Response extends BDXBody implements Serializable {
}
